package com.shadowgaminghub.instagramgrowth

import android.app.Activity
import android.os.Bundle
import android.content.Context
import android.graphics.Color
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.*
import android.text.InputType

class MainActivity : Activity() {
    private val prefs by lazy { getSharedPreferences("growth_data", Context.MODE_PRIVATE) }
    private val bg = Color.rgb(14, 17, 24)
    private val card = Color.rgb(27, 32, 43)
    private val accent = Color.rgb(180, 92, 255)
    private val white = Color.WHITE
    private lateinit var root: LinearLayout

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        showDashboard()
    }

    private fun setup(title: String) {
        root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(20, 24, 20, 24)
            setBackgroundColor(bg)
        }
        val scroll = ScrollView(this)
        scroll.addView(root)
        setContentView(scroll)
        text(root, title, 26f, white, true)
        text(root, "FREE • OFFLINE • NO PAID API REQUIRED", 11f, accent, true)
        space(root, 16)
    }

    private fun showDashboard() {
        setup("IG Growth Elite")
        text(root, "Your growth command centre", 16f, white, true)
        space(root, 12)
        val current = EditText(this).apply {
            hint = "Current follower count (e.g. 450)"
            setHintTextColor(Color.LTGRAY)
            setTextColor(white)
            inputType = InputType.TYPE_CLASS_NUMBER
            setText(prefs.getInt("followers", 450).toString())
            setPadding(14, 12, 14, 12)
            setBackgroundColor(card)
        }
        root.addView(current, matchWrap())
        space(root, 8)
        val goal = EditText(this).apply {
            hint = "Target followers (e.g. 10000)"
            setHintTextColor(Color.LTGRAY)
            setTextColor(white)
            inputType = InputType.TYPE_CLASS_NUMBER
            setText(prefs.getInt("goal", 10000).toString())
            setPadding(14, 12, 14, 12)
            setBackgroundColor(card)
        }
        root.addView(goal, matchWrap())
        space(root, 8)
        button(root, "SAVE MY TARGET") {
            val f = current.text.toString().toIntOrNull() ?: 0
            val g = goal.text.toString().toIntOrNull() ?: 10000
            prefs.edit().putInt("followers", f).putInt("goal", g).apply()
            Toast.makeText(this, "Progress saved on this phone", Toast.LENGTH_SHORT).show()
        }
        space(root, 12)
        val f = prefs.getInt("followers", 450)
        val g = prefs.getInt("goal", 10000)
        panel(root, "CURRENT PROGRESS", "$f followers  →  target $g")
        space(root, 12)
        button(root, "DAILY GROWTH PLAN") { showPlan() }
        button(root, "CAPTION + HASHTAG GENERATOR") { showGenerator("caption") }
        button(root, "REELS IDEAS GENERATOR") { showGenerator("reels") }
        button(root, "HASHTAG IDEAS") { showGenerator("hashtags") }
        button(root, "WEEKLY TRACKER") { showTracker() }
        space(root, 16)
        text(root, "Note: This app helps plan genuine growth. It does not create fake followers or automatically interact with Instagram.", 13f, Color.LTGRAY, false)
    }

    private fun showPlan() {
        setup("Your daily growth plan")
        panel(root, "1. CREATE", "Publish one useful Reel with a clear opening hook in the first 2 seconds.")
        panel(root, "2. ENGAGE", "Spend 15 minutes leaving thoughtful comments on relevant public posts in your niche.")
        panel(root, "3. CONNECT", "Reply to comments and messages genuinely. Do not spam people.")
        panel(root, "4. LEARN", "Review yesterday's reach, watch time, shares, saves, and profile visits.")
        panel(root, "5. REPEAT", "Reuse topics that perform well, but make each post original.")
        button(root, "BACK TO DASHBOARD") { showDashboard() }
    }

    private fun showGenerator(type: String) {
        val title = when(type) {
            "caption" -> "Caption generator"
            "reels" -> "Reels idea generator"
            else -> "Hashtag ideas"
        }
        setup(title)
        text(root, "Choose your niche to personalize suggestions.", 14f, Color.LTGRAY, false)
        val niche = EditText(this).apply {
            hint = "Your niche (e.g. gaming, food, fashion)"
            setHintTextColor(Color.LTGRAY)
            setTextColor(white)
            setPadding(14, 12, 14, 12)
            setBackgroundColor(card)
        }
        root.addView(niche, matchWrap())
        space(root, 8)
        val result = TextView(this).apply {
            setTextColor(white)
            textSize = 15f
            setPadding(16, 16, 16, 16)
            setBackgroundColor(card)
        }
        root.addView(result, matchWrap())
        space(root, 8)
        button(root, "GENERATE") {
            val n = niche.text.toString().trim().ifBlank { "your niche" }
            result.text = when(type) {
                "caption" -> "HOOK: Most people overlook this about $n.\n\nBODY: Here is one thing I have learned about $n. Save this post if it helped, and tell me your experience in the comments.\n\nCTA: Follow for more original $n content.\n\nTip: Make the caption specific to the actual post; avoid misleading claims."
                "reels" -> "REEL IDEA FOR $n\n\n1. Hook (0–2 sec): “3 things I wish I knew about $n.”\n2. Value (3–12 sec): Show three quick tips or examples.\n3. Payoff (13–18 sec): Demonstrate the most useful tip.\n4. CTA: Ask viewers which tip they will try.\n\nFilm vertically, use clear on-screen text, and keep it original."
                else -> "Hashtag mix for $n:\n\n#${cleanTag(n)} #${cleanTag(n)}Tips #${cleanTag(n)}Community #Learn${cleanTag(n)} #${cleanTag(n)}Creator\n\nUse only tags that accurately describe your post. Mix niche-specific tags with relevant topic tags; avoid unrelated trending tags."
            }
        }
        button(root, "BACK TO DASHBOARD") { showDashboard() }
    }

    private fun showTracker() {
        setup("Weekly tracker")
        text(root, "Enter your follower count once a day and save it in your notes or compare it with your previous count. This starter version keeps the latest target locally.", 15f, Color.LTGRAY, false)
        val f = prefs.getInt("followers", 450)
        val g = prefs.getInt("goal", 10000)
        panel(root, "STARTING POINT", "$f followers")
        panel(root, "TARGET", "$g followers")
        panel(root, "NEXT ACTION", "Record your current count today, then check again in 7 days. Compare growth with reach, shares, saves, and profile visits.")
        button(root, "BACK TO DASHBOARD") { showDashboard() }
    }

    private fun cleanTag(s: String): String = s.filter { it.isLetterOrDigit() }.take(24).ifBlank { "Creator" }

    private fun panel(parent: LinearLayout, heading: String, body: String) {
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(16, 14, 16, 14)
            setBackgroundColor(card)
        }
        text(box, heading, 12f, accent, true)
        space(box, 5)
        text(box, body, 15f, white, false)
        val lp = LinearLayout.LayoutParams(-1, -2)
        lp.bottomMargin = 10
        parent.addView(box, lp)
    }

    private fun button(parent: LinearLayout, label: String, action: () -> Unit) {
        val b = Button(this).apply {
            text = label
            setTextColor(white)
            setBackgroundColor(accent)
            textSize = 13f
            setOnClickListener { action() }
        }
        val lp = LinearLayout.LayoutParams(-1, -2)
        lp.bottomMargin = 8
        parent.addView(b, lp)
    }

    private fun text(parent: LinearLayout, value: String, size: Float, color: Int, bold: Boolean) {
        val t = TextView(this).apply {
            text = value
            textSize = size
            setTextColor(color)
            if (bold) setTypeface(null, android.graphics.Typeface.BOLD)
        }
        parent.addView(t, LinearLayout.LayoutParams(-1, -2))
    }

    private fun space(parent: LinearLayout, height: Int) {
        parent.addView(View(this), LinearLayout.LayoutParams(1, height))
    }

    private fun matchWrap() = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
}
