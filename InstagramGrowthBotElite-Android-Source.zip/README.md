# Instagram Growth Bot Elite (Android starter)

A free, offline-first Android app that helps plan genuine Instagram growth. It does not generate fake followers, automate spam, or ask for your Instagram password.

## Included
- Native Android Kotlin app
- Local follower target settings
- Daily growth checklist
- Basic caption, hashtag, and Reels idea generators
- No paid APIs, subscriptions, or internet permission in this starter

## Build an APK for free
### Option 1: Android Studio
1. Install Android Studio on a computer.
2. Open this project folder.
3. Allow Gradle to sync.
4. Choose Build > Build APK(s).
5. The debug APK is usually under `app/build/outputs/apk/debug/app-debug.apk`.

### Option 2: GitHub Actions
Upload this project to a GitHub repository and add a workflow that builds with Gradle. You still need a Gradle wrapper to make CI builds reliable; generate it once using Android Studio or `gradle wrapper`.

## Notes
- This is a starter app, not an Instagram-connected bot.
- Official Instagram publishing/insights integrations may require an eligible professional account, Meta app setup, permissions, and review.
- Growth is not guaranteed. Focus on original content, audience relevance, and authentic engagement.
